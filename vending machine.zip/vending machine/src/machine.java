import java.util.ArrayList;
import java.util.Scanner;

public class machine {
	
 public static  ArrayList<String> item = new ArrayList<String>(10);
 public static  ArrayList<Double> cost = new ArrayList<Double>(10);
 Scanner choose = new Scanner(System.in);
	static int pay;
	static int c;
	
	
	public static void productsAvailable () {

		System.out.println("the items in the vending machine are:"+ item);
		System.out.println("the cost of these items in the vending machine are:"+ cost+ "\r\n");
		
		}
	
	public void clientConfirmation() {
	
		if (pay==cost.get(c-1)) {
			System.out.println("change:"+ 0);
			System.out.println("you have your item, have a nice day :)");
		}
		
		else if(pay>cost.get(c-1)) {
			double change = pay-cost.get(c-1);
			System.out.println("change:"+ change);
			System.out.println("you have your item, have a nice day :)");
		}
		
		else if(pay<cost.get(c-1) && pay!=000) {
			double due = cost.get(c-1)-pay;
			System.out.println("change: -"+due + "\r\n"+ " please complete the payment");
			c=choose.nextInt();
		}
		
	}
	
	
	
	

}
