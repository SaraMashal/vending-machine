import java.util.Scanner;

public class assistance extends machine {
	
	Scanner fill = new Scanner(System.in);
	

	public void refill () {
		
		
		int i=10;
		while( i>=item.size()) {
			System.out.println("[-------please enter the next products in the vending machine-------]");
		item.add(fill.nextLine());
		}
		
	}
		
     public void costSet() {
    	
    	 int i=10;
 		while( i>=cost.size()) {
 			 System.out.println("[********please enter the cost for every item in the vending machine**********]");
 		cost.add(fill.nextDouble());
 		}
 		
 		super.productsAvailable();
}
	}


