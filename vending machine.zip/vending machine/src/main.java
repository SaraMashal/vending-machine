import java.util.ArrayList;
import java.util.Scanner;

public class main extends machine {
static Scanner fill = new Scanner(System.in);
	
public static void main(String[] args) {
	assistance  obj = new assistance() ;
	client obj2 = new client();
	angryClient obj3 = new angryClient();
	
	
	for(int i=0;i>=0; i++) {
	System.out.println("please choose a number of the following: \r\n 1.vendor/assistant \r\n 2.client \r\n 3.angry client");
	String f = fill.nextLine();
	

	if (f.equals("1")) {
		
		obj.refill();
		obj.costSet();
		}
	;
	if(f.equals("2")) {
		obj2.itemSelection();
		
	}
	
	 if(f.equals("3")) {
		obj3.itemSelection();
		System.out.println("the machine is getting kicked successfully");
	}
	
	
	}
	}
}

