
public class angryClient extends machine{
	void itemSelection() {
		if(item.size()==0) {
			System.out.println("the machine is empty, call assistance on this number \r\n 050-123458323");
		}
		
		else {

		System.out.println("the items in the vending machine are:"+ item);
		System.out.println("the cost of these items in the vending machine are:"+ cost);
		System.out.println("please choose an item and kick the machine >:(");
		 c=choose.nextInt();
		System.out.println("your item that you chose is: "+item.get(c-1) + " and it costs:"+cost.get(c-1)+" AED");
		this.payment();
		}
	
		
	}
	
	void payment() {
		System.out.println("please proceed with the payment or type 000 to cancel");
		pay = choose.nextInt();
		if (pay==cost.get(c-1)) {
			item.remove(c-1);
			super.clientConfirmation();
			System.out.println("kick the machine to have your item, have a nice day >:(");
			
		}
		else if(pay!=cost.get(c-1) && pay!=00) {
		super.clientConfirmation();
		this.payment();
		}
		else if(pay==000) {
			this.itemSelection();
			
		}
	}

}
